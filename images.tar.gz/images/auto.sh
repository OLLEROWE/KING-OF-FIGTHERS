#!/bin/bash

# 设定输入文件夹
input_dir="./"  # 替换为你想要处理的文件夹路径

# 遍历输入文件夹中的所有.gif文件
for gif_file in "$input_dir"*.gif; do
    # 提取文件名（不带扩展名）
    filename=$(basename -- "$gif_file" .gif)

    # 构造输出文件名
    png_file="$input_dir$filename.png"

    # 使用magick或convert命令将gif转换为png
    # 注意：在较新版本的ImageMagick中，应该使用magick，但convert可能仍然可用
    magick convert "$gif_file" -coalesce  +append "$png_file"
    # 或者，如果你仍然使用convert命令（不是magick）
    # convert "$gif_file" -coalesce "$png_file"

    # 输出转换信息
    echo "Converted $gif_file to $png_file"
done
    rm *.gif
echo "All GIF files have been converted to PNG."
